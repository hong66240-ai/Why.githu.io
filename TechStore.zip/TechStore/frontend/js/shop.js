document.addEventListener('DOMContentLoaded', () => {
  const grid = document.getElementById('product-grid');
  const filterBar = document.getElementById('filter-bar');
  const searchInput = document.getElementById('search-input');

  let activeCategory = qs('category') || '';
  let activeSearch = qs('search') || '';

  if (searchInput) searchInput.value = activeSearch;

  async function loadCategories() {
    if (!filterBar) return;
    try {
      const categories = await Api.getCategories();
      const chips = [{ slug: '', name: 'All' }, ...categories];
      filterBar.innerHTML = chips.map(c => `
        <button class="filter-chip ${c.slug === activeCategory ? 'active' : ''}" data-slug="${c.slug}">
          ${c.name}
        </button>
      `).join('');

      filterBar.querySelectorAll('.filter-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          activeCategory = chip.dataset.slug;
          filterBar.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
          chip.classList.add('active');
          loadProducts();
        });
      });
    } catch (e) {
      filterBar.innerHTML = '';
    }
  }

  function renderProductCard(p) {
    const img = (p.imageUrls && p.imageUrls[0]) ? `<img src="${p.imageUrls[0]}" alt="${p.name}">` : 'NO IMAGE';
    const hasDiscount = p.discountPrice != null;
    const outOfStock = p.stockQuantity <= 0;

    return `
      <a class="product-card" href="product.html?slug=${p.slug}">
        <div class="product-thumb">${img}</div>
        <div class="product-body">
          <div class="product-brand">${p.brand || p.categoryName || 'TechStore'}</div>
          <div class="product-name">${p.name}</div>
          <div class="price-row">
            <span class="price">${formatPrice(hasDiscount ? p.discountPrice : p.price)}</span>
            ${hasDiscount ? `<span class="price-strike">${formatPrice(p.price)}</span>` : ''}
          </div>
          <div class="spec-ticker">[SKU <b>${p.sku || '—'}</b>] [STOCK <b>${outOfStock ? '0' : p.stockQuantity}</b>]</div>
        </div>
      </a>
    `;
  }

  async function loadProducts() {
    if (!grid) return;
    grid.innerHTML = '<div class="loading-row">Loading products…</div>';
    try {
      const params = { size: 24 };
      if (activeCategory) params.category = activeCategory;
      if (activeSearch) params.search = activeSearch;

      const page = await Api.getProducts(params);
      const products = page.content || [];

      if (products.length === 0) {
        grid.innerHTML = '<div class="loading-row">No products match that search.</div>';
        return;
      }

      grid.innerHTML = products.map(renderProductCard).join('');
    } catch (e) {
      grid.innerHTML = `<div class="loading-row">Could not load products: ${e.message}</div>`;
    }
  }

  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        activeSearch = searchInput.value.trim();
        loadProducts();
      }
    });
  }

  loadCategories();
  loadProducts();
});
