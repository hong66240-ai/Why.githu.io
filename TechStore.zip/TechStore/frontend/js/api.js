/* ============================================================
   TechStore — API client
   Talks to the Spring Boot backend at API_BASE. All pages load
   this file first.
   ============================================================ */

const API_BASE = 'http://localhost:8080/api';

const Auth = {
  getToken() {
    return localStorage.getItem('ts_token');
  },
  getUser() {
    const raw = localStorage.getItem('ts_user');
    return raw ? JSON.parse(raw) : null;
  },
  isLoggedIn() {
    return !!this.getToken();
  },
  save(authResponse) {
    localStorage.setItem('ts_token', authResponse.token);
    localStorage.setItem('ts_user', JSON.stringify({
      userId: authResponse.userId,
      firstName: authResponse.firstName,
      lastName: authResponse.lastName,
      email: authResponse.email,
      role: authResponse.role
    }));
  },
  clear() {
    localStorage.removeItem('ts_token');
    localStorage.removeItem('ts_user');
  }
};

async function apiRequest(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = Auth.getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${API_BASE}${path}`, { ...options, headers });

  let body = null;
  const text = await response.text();
  if (text) {
    try { body = JSON.parse(text); } catch (e) { body = text; }
  }

  if (!response.ok) {
    const message = (body && body.message) ? body.message : `Request failed (${response.status})`;
    throw new Error(message);
  }

  return body;
}

const Api = {
  register: (data) => apiRequest('/auth/register', { method: 'POST', body: JSON.stringify(data) }),
  login: (data) => apiRequest('/auth/login', { method: 'POST', body: JSON.stringify(data) }),

  getCategories: () => apiRequest('/categories'),

  getProducts: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/products${query ? '?' + query : ''}`);
  },
  getProduct: (slug) => apiRequest(`/products/${slug}`),

  getCart: () => apiRequest('/cart'),
  addToCart: (productId, quantity = 1) =>
    apiRequest('/cart/items', { method: 'POST', body: JSON.stringify({ productId, quantity }) }),
  updateCartItem: (itemId, quantity) =>
    apiRequest(`/cart/items/${itemId}?quantity=${quantity}`, { method: 'PUT' }),
  removeCartItem: (itemId) =>
    apiRequest(`/cart/items/${itemId}`, { method: 'DELETE' })
};

function formatPrice(value) {
  const num = Number(value);
  return `$${num.toFixed(2)}`;
}

function qs(name) {
  return new URLSearchParams(window.location.search).get(name);
}

/* Shared header state: login/logout link + cart count badge */
async function renderHeaderState() {
  const authSlot = document.getElementById('auth-slot');
  const cartCountEl = document.querySelector('.cart-pill .count');

  if (authSlot) {
    if (Auth.isLoggedIn()) {
      const user = Auth.getUser();
      authSlot.innerHTML = `
        <a href="profile.html">${user.firstName}</a>
        <a href="#" id="logout-link">Log out</a>
      `;
      const logoutLink = document.getElementById('logout-link');
      if (logoutLink) {
        logoutLink.addEventListener('click', (e) => {
          e.preventDefault();
          Auth.clear();
          window.location.href = 'index.html';
        });
      }
    } else {
      authSlot.innerHTML = `<a href="login.html">Log in</a>`;
    }
  }

  if (cartCountEl) {
    if (Auth.isLoggedIn()) {
      try {
        const cart = await Api.getCart();
        cartCountEl.textContent = cart.totalItems || 0;
      } catch (e) {
        cartCountEl.textContent = '0';
      }
    } else {
      cartCountEl.textContent = '0';
    }
  }
}

document.addEventListener('DOMContentLoaded', renderHeaderState);
