document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('product-detail');
  const slug = qs('slug');

  if (!container) return;

  if (!slug) {
    container.innerHTML = '<p class="muted">No product specified.</p>';
    return;
  }

  try {
    const p = await Api.getProduct(slug);
    const hasDiscount = p.discountPrice != null;
    const inStock = p.stockQuantity > 0;
    const img = (p.imageUrls && p.imageUrls[0]) ? `<img src="${p.imageUrls[0]}" alt="${p.name}">` : 'NO IMAGE';

    document.title = `${p.name} — TechStore`;

    container.innerHTML = `
      <div class="product-detail-grid">
        <div class="product-gallery">${img}</div>
        <div>
          <div class="product-brand">${p.brand || p.categoryName || 'TechStore'}</div>
          <h1>${p.name}</h1>
          <span class="stock-badge ${inStock ? 'stock-in' : 'stock-out'}">
            ${inStock ? `IN STOCK · ${p.stockQuantity} UNITS` : 'OUT OF STOCK'}
          </span>

          <div class="price-row mt-24">
            <span class="price" style="font-size:1.6rem">${formatPrice(hasDiscount ? p.discountPrice : p.price)}</span>
            ${hasDiscount ? `<span class="price-strike">${formatPrice(p.price)}</span>` : ''}
          </div>

          <p class="mt-24">${p.description || ''}</p>

          <div class="qty-control mt-24" id="qty-control">
            <button type="button" id="qty-dec">-</button>
            <span id="qty-value">1</span>
            <button type="button" id="qty-inc">+</button>
          </div>

          <button class="btn btn-accent btn-block mt-24" id="add-to-cart" ${inStock ? '' : 'disabled'}>
            ${inStock ? 'Add to cart' : 'Out of stock'}
          </button>
          <div class="alert alert-success" id="cart-alert">Added to cart.</div>

          <div class="spec-panel mt-24">
            <h3>Specifications</h3>
            <div class="spec-row"><span class="k">BRAND</span><span class="v">${p.brand || '—'}</span></div>
            <div class="spec-row"><span class="k">CATEGORY</span><span class="v">${p.categoryName || '—'}</span></div>
            <div class="spec-row"><span class="k">SKU</span><span class="v">${p.sku || '—'}</span></div>
          </div>
        </div>
      </div>
    `;

    let qty = 1;
    const qtyValue = document.getElementById('qty-value');
    document.getElementById('qty-inc').addEventListener('click', () => {
      qty += 1;
      qtyValue.textContent = qty;
    });
    document.getElementById('qty-dec').addEventListener('click', () => {
      qty = Math.max(1, qty - 1);
      qtyValue.textContent = qty;
    });

    document.getElementById('add-to-cart').addEventListener('click', async () => {
      if (!Auth.isLoggedIn()) {
        window.location.href = `login.html?next=product.html?slug=${slug}`;
        return;
      }
      try {
        await Api.addToCart(p.id, qty);
        document.getElementById('cart-alert').classList.add('show');
        renderHeaderState();
      } catch (e) {
        alert(e.message);
      }
    });
  } catch (e) {
    container.innerHTML = `<p class="muted">Could not load this product: ${e.message}</p>`;
  }
});
