document.addEventListener('DOMContentLoaded', async () => {
  const listEl = document.getElementById('cart-list');
  const summaryEl = document.getElementById('cart-summary');
  const layoutEl = document.getElementById('cart-layout');
  const emptyEl = document.getElementById('cart-empty');

  if (!listEl) return;

  if (!Auth.isLoggedIn()) {
    window.location.href = 'login.html?next=cart.html';
    return;
  }

  function renderLine(item) {
    const img = item.imageUrl ? `<img src="${item.imageUrl}" alt="${item.productName}">` : 'IMG';
    return `
      <div class="cart-line" data-item-id="${item.id}">
        <div class="cart-thumb">${img}</div>
        <div>
          <div style="font-weight:600">${item.productName}</div>
          <div class="mono muted" style="font-size:0.82rem">${formatPrice(item.unitPrice)} each</div>
        </div>
        <div class="qty-control">
          <button type="button" class="qty-dec">-</button>
          <span>${item.quantity}</span>
          <button type="button" class="qty-inc">+</button>
        </div>
        <div style="text-align:right">
          <div class="mono" style="font-weight:700">${formatPrice(item.lineTotal)}</div>
          <a href="#" class="remove-link muted" style="font-size:0.8rem">Remove</a>
        </div>
      </div>
    `;
  }

  function renderSummary(cart) {
    const shipping = cart.subtotal > 0 ? 9.99 : 0;
    const tax = cart.subtotal * 0.08;
    const total = Number(cart.subtotal) + shipping + tax;

    summaryEl.innerHTML = `
      <h3>Order summary</h3>
      <div class="summary-row"><span>Items (${cart.totalItems})</span><span class="mono">${formatPrice(cart.subtotal)}</span></div>
      <div class="summary-row"><span>Shipping</span><span class="mono">${formatPrice(shipping)}</span></div>
      <div class="summary-row"><span>Estimated tax</span><span class="mono">${formatPrice(tax)}</span></div>
      <div class="summary-row total"><span>Total</span><span>${formatPrice(total)}</span></div>
      <a href="checkout.html" class="btn btn-accent btn-block mt-24">Checkout</a>
    `;
  }

  async function refreshQty(itemId, quantity) {
    try {
      await Api.updateCartItem(itemId, quantity);
      await load();
      renderHeaderState();
    } catch (e) {
      alert(e.message);
    }
  }

  async function removeItem(itemId) {
    try {
      await Api.removeCartItem(itemId);
      await load();
      renderHeaderState();
    } catch (e) {
      alert(e.message);
    }
  }

  async function load() {
    try {
      const cart = await Api.getCart();

      if (!cart.items || cart.items.length === 0) {
        layoutEl.style.display = 'none';
        emptyEl.style.display = 'block';
        return;
      }

      layoutEl.style.display = '';
      emptyEl.style.display = 'none';

      listEl.innerHTML = cart.items.map(renderLine).join('');
      renderSummary(cart);

      listEl.querySelectorAll('.cart-line').forEach(line => {
        const itemId = line.dataset.itemId;
        const qtySpan = line.querySelector('.qty-control span');

        line.querySelector('.qty-inc').addEventListener('click', () => {
          refreshQty(itemId, parseInt(qtySpan.textContent, 10) + 1);
        });
        line.querySelector('.qty-dec').addEventListener('click', () => {
          const next = parseInt(qtySpan.textContent, 10) - 1;
          if (next <= 0) { removeItem(itemId); return; }
          refreshQty(itemId, next);
        });
        line.querySelector('.remove-link').addEventListener('click', (e) => {
          e.preventDefault();
          removeItem(itemId);
        });
      });
    } catch (e) {
      listEl.innerHTML = `<div class="loading-row">Could not load your cart: ${e.message}</div>`;
    }
  }

  load();
});
