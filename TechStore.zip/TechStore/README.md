# TechStore — Full-stack online store

A tech e-commerce app: static HTML/CSS/JS frontend, a Spring Boot (Java 17) REST backend, and a MySQL schema.

```
TechStore/
├── frontend/       static site (no build step) — HTML, CSS, vanilla JS
├── backend/        Spring Boot 3 REST API (Maven)
└── database/       techstore.sql — schema + seed data
```

## What's implemented

**Backend** (`/api`)
- `POST /api/auth/register`, `POST /api/auth/login` — JWT-based auth, BCrypt password hashing
- `GET /api/products`, `GET /api/products/{slug}` — paginated catalog, filter by `category` or `search`
- `GET /api/categories`
- `GET /api/cart`, `POST /api/cart/items`, `PUT /api/cart/items/{id}?quantity=`, `DELETE /api/cart/items/{id}` — all require a bearer token
- Global exception handling, request validation, CORS configured for local dev

**Frontend**
- `index.html` / `shop.html` — product grid, category filter, search
- `product.html` — product detail + add to cart
- `cart.html` — line-item quantity controls, live subtotal
- `login.html` / `register.html` — JWT stored in `localStorage`
- `checkout.html` — shipping form + order summary (UI only — see note below)
- `profile.html`, `about.html`, `contact.html`

**Not implemented (left as a next step)**
- No `/api/orders` endpoint — checkout collects a shipping address and shows the order total, but "Place order" doesn't persist anything yet. The `orders` / `order_items` tables already exist in `techstore.sql`, so this is mostly a controller + service to add.
- No admin panel for managing products/categories (would insert/update through the database directly, or via a future admin API).
- No product image upload — `product_images` table exists; seed data doesn't populate any, so cards show a "NO IMAGE" placeholder.

## Running it locally

### 1. Database
```bash
mysql -u root -p < database/techstore.sql
```
This creates the `techstore` database, tables, and a few seed products/categories.

### 2. Backend
Edit `backend/src/main/resources/application.properties` if your MySQL user/password differ from `root`/`root`. Then:
```bash
cd backend
mvn spring-boot:run
```
API runs on `http://localhost:8080`.

### 3. Frontend
The frontend is static — no build tooling. Easiest options:
```bash
cd frontend
python3 -m http.server 5500
```
Then open `http://localhost:5500`. (Any static server works — Live Server in VS Code, `npx serve`, etc. Just make sure the port matches one of the origins in `app.cors.allowed-origins` in `application.properties`, or add yours.)

`frontend/js/api.js` points at `http://localhost:8080/api` — change `API_BASE` there if the backend runs elsewhere.

## Auth flow
Register or log in → the backend returns a JWT → the frontend stores it in `localStorage` and sends it as `Authorization: Bearer <token>` on cart requests. There's no refresh token; the token expires after 24h (`app.jwt.expiration-ms`).
