package com.techstore.service;

import com.techstore.dto.ProductDTO;
import com.techstore.entity.Product;
import com.techstore.exception.ResourceNotFoundException;
import com.techstore.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public Page<ProductDTO> getProducts(String categorySlug, String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Product> products;

        if (search != null && !search.isBlank()) {
            products = productRepository.findByActiveTrueAndNameContainingIgnoreCase(search, pageable);
        } else if (categorySlug != null && !categorySlug.isBlank()) {
            products = productRepository.findByActiveTrueAndCategory_Slug(categorySlug, pageable);
        } else {
            products = productRepository.findByActiveTrue(pageable);
        }

        return products.map(this::toDTO);
    }

    public ProductDTO getBySlug(String slug) {
        Product product = productRepository.findBySlug(slug)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + slug));
        return toDTO(product);
    }

    private ProductDTO toDTO(Product p) {
        return ProductDTO.builder()
                .id(p.getId())
                .name(p.getName())
                .slug(p.getSlug())
                .description(p.getDescription())
                .brand(p.getBrand())
                .price(p.getPrice())
                .discountPrice(p.getDiscountPrice())
                .stockQuantity(p.getStockQuantity())
                .sku(p.getSku())
                .categoryName(p.getCategory() != null ? p.getCategory().getName() : null)
                .imageUrls(p.getImages() == null ? java.util.List.of() :
                        p.getImages().stream().map(com.techstore.entity.ProductImage::getImageUrl).toList())
                .build();
    }
}
