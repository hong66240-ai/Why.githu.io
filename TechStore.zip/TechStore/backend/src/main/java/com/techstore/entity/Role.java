package com.techstore.entity;

public enum Role {
    CUSTOMER,
    ADMIN
}
