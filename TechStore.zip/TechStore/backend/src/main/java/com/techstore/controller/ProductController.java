package com.techstore.controller;

import com.techstore.dto.ProductDTO;
import com.techstore.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @GetMapping
    public ResponseEntity<Page<ProductDTO>> getProducts(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(productService.getProducts(category, search, page, size));
    }

    @GetMapping("/{slug}")
    public ResponseEntity<ProductDTO> getProduct(@PathVariable String slug) {
        return ResponseEntity.ok(productService.getBySlug(slug));
    }
}
